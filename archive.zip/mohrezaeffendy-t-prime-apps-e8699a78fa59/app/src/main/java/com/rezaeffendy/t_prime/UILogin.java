package com.rezaeffendy.t_prime;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class UILogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uilogin);
    }

    public void LOGIN(View view) {
    }

    public void REGISTER(View view) {
    }
}
